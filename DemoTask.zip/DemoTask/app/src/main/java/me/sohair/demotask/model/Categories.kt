package me.sohair.demotask.model

class Categories {
    var catName: String? = null
    var catUrl: String? = null

    constructor(catName:String?, catUrl:String?){
        this.catName = catName
        this.catUrl = catUrl
    }


}